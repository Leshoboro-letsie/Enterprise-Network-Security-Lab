

# IP Addressing and VLAN Design

## 1. Purpose

This document defines the IPv4 addressing scheme, VLAN structure, default gateways, and network segmentation used in the Enterprise Network & Security Lab.

The design separates departments and infrastructure into dedicated VLANs to improve:

- Security
- Network organization
- Traffic control
- Troubleshooting
- Scalability
- Access management

---

## 2. VLAN Addressing Plan

| VLAN | Name | Network | Subnet Mask | Default Gateway | Purpose |
|------|------|---------|-------------|-----------------|---------|
| 10 | MANAGEMENT | 192.168.10.0/24 | 255.255.255.0 | 192.168.10.1 | Management |
| 20 | IT | 192.168.20.0/24 | 255.255.255.0 | 192.168.20.1 | IT Department |
| 30 | FINANCE | 192.168.30.0/24 | 255.255.255.0 | 192.168.30.1 | Finance |
| 40 | HR | 192.168.40.0/24 | 255.255.255.0 | 192.168.40.1 | Human Resources |
| 50 | USERS | 192.168.50.0/24 | 255.255.255.0 | 192.168.50.1 | General Users |
| 60 | SERVERS | 192.168.60.0/24 | 255.255.255.0 | 192.168.60.1 | Servers |
| 70 | GUEST | 192.168.70.0/24 | 255.255.255.0 | 192.168.70.1 | Guest Wireless |
| 99 | NETWORK-MGMT | 192.168.99.0/24 | 255.255.255.0 | 192.168.99.1 | Network Management |

---

## 3. VLAN Purpose

### VLAN 10 — MANAGEMENT

Network:

```text
  192.168.10.0/24
```

Gateway:

```text
  192.168.10.1
```

Used for management-related devices and administrative connectivity.

---

### VLAN 20 — IT

Network:

```text
  192.168.20.0/24
```

Gateway:

```text
  192.168.20.1
```

Used for IT department systems and workstations.

---

### VLAN 30 — FINANCE

Network:

```text
  192.168.30.0/24
```

Gateway:

```text
  192.168.30.1
```

Used for Finance department systems.

Access to this VLAN is controlled using ACL policies.

---

### VLAN 40 — HR

Network:

```text
  192.168.40.0/24
```

Gateway:

```text
  192.168.40.1
```

Used for Human Resources systems and workstations.

---

### VLAN 50 — USERS

Network:

```text
  192.168.50.0/24
```

Gateway:

```text
  192.168.50.1
```

Used for general organizational users.

---

### VLAN 60 — SERVERS

Network:

```text
  192.168.60.0/24
```

Gateway:

```text
  192.168.60.1
```

Dedicated network for server infrastructure.

Server traffic is separated from normal user traffic.

---

### VLAN 70 — GUEST

Network:

```text
  192.168.70.0/24
```

Gateway:

```text
  192.168.70.1
```

Used for guest wireless clients.

Guest traffic is restricted from accessing protected internal VLANs.

Guest users are permitted to access external network resources where allowed.

---

### VLAN 99 — NETWORK-MGMT

Network:

```text
  192.168.99.0/24
```

Gateway:

```text
  192.168.99.1
```

Dedicated management network for network infrastructure.

---

## 4. Core Layer 3 Architecture

SW1-CORE operates as the Layer 3 core switch.

Each VLAN has an SVI configured as its default gateway.

Example:

```text
  interface Vlan70
  ip address 192.168.70.1 255.255.255.0
```

The SVI provides the Layer 3 gateway for VLAN 70.

The same design is applied to the other VLANs.

---

## 5. Core-to-Edge Transit Network

The Layer 3 connection between SW1-CORE and R1-EDGE uses:

```text
  Network: 10.255.255.0/30
```

Addressing:

| Device | Interface | IP Address |
|--------|-----------|------------|
| SW1-CORE | G0/1 | 10.255.255.1/30 |
| R1-EDGE | Internal Interface | 10.255.255.2/30 |

This network provides routed connectivity between the enterprise core and edge router.

---

## 6. WAN Network

The WAN connection between R1-EDGE and ISP-R1 uses:

```text
  Network: 203.0.113.0/30
```

Addressing:

| Device | IP Address |
|--------|------------|
| R1-EDGE | 203.0.113.1/30 |
| ISP-R1 | 203.0.113.2/30 |

---

## 7. Simulated External Network

The simulated external network uses:

```text
  Network: 198.51.100.0/24
```

ISP-R1:

```text
  198.51.100.1/24
```

External server:

```text
  198.51.100.10/24
```

The external server represents an Internet-based resource for testing.

---

## 8. VLAN Trunking

The access switches connect to the core using 802.1Q trunking.

The following VLANs are carried across the trunk:

```text
  10
  20
  30
  40
  50
  60
  70
  99
```

Trunk verification was performed using:

```text
  show interfaces trunk
```

The trunk was verified as operational with the required VLANs active and forwarding.

---

## 9. DHCP Address Allocation

DHCP is provided by SW1-CORE.

Infrastructure addresses are excluded from the DHCP pools.

Example:

```text
  ip dhcp excluded-address 192.168.70.1 192.168.70.20
```

The Guest network uses:

```text
  Network: 192.168.70.0/24
  Gateway: 192.168.70.1
  DNS: 8.8.8.8
```

DHCP operation was verified using:

```text
  show ip dhcp pool
  show ip dhcp binding
```

---

## 10. Guest Network Design

The Guest network is intentionally separated from internal organizational networks.

Traffic flow:

```text
  Guest Laptop
     |
 Access Point
     |
 SW4-ACCESS
     |
 VLAN 70
     |
 SW1-CORE
     |
     +------> Internal Networks  ❌
     |
     +------> R1-EDGE → ISP      ✅
```

This design provides controlled Internet access while reducing the risk of Guest users accessing internal resources.

---

## 11. Security Segmentation

The VLAN structure provides logical separation between:

- Management
- IT
- Finance
- HR
- General Users
- Servers
- Guest users
- Network management

ACLs are used to enforce additional restrictions between these security zones.

---

## 12. Design Benefits

The addressing and VLAN architecture provides:

- Clear network segmentation
- Reduced broadcast domains
- Improved security
- Easier troubleshooting
- Controlled inter-department communication
- Dedicated Guest network
- Dedicated server network
- Dedicated management network
- Scalable IPv4 addressing
- Centralized DHCP
- Controlled Internet access

---

## 13. Verification

The addressing plan was validated through:

```text
  show vlan brief
  show ip interface brief
  show ip route
  show interfaces trunk
  show ip dhcp pool
  show ip dhcp binding
```

Connectivity was also tested between appropriate network segments and the simulated external network.

---

## 14. Final Design Summary

The network uses a structured VLAN and IPv4 addressing scheme with `/24` departmental networks and `/30` point-to-point transit networks.

SW1-CORE provides the Layer 3 gateway functions, while R1-EDGE provides WAN connectivity and NAT/PAT.

The architecture separates internal departments, servers, management infrastructure, and Guest wireless users into controlled security zones.

**Design Status: Completed and Verified**