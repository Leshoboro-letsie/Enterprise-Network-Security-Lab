# Troubleshooting and Lessons Learned

## 1. Purpose

This document records the main troubleshooting activities performed during implementation of the Enterprise Network & Security Lab.

The objective was to identify configuration and connectivity problems, determine their causes, apply corrective actions, and verify successful operation.

---

## 2. Guest DHCP Failure

### Symptom

The Guest laptop initially failed to obtain an IPv4 address.

The client displayed:

```text
  DHCP request failed
```

The wireless connection to the Guest Access Point was operational, but the client received:

```text
  IPv4 Address: 0.0.0.0
  Subnet Mask: 0.0.0.0
  Default Gateway: 0.0.0.0
```

### Investigation

The following areas were checked:

* Guest VLAN configuration
* Access Point connection
* SW4-ACCESS Fa0/3
* Trunk connectivity
* VLAN 70 SVI
* DHCP pool
* Guest ACL

The switch port was verified:

```text
  Fa0/3
  Access Mode VLAN: 70 (GUEST)
  Status: connected
```

The trunk was also verified to carry VLAN 70.

### Root Cause

The Guest DHCP pool was initially incomplete.

The pool did not contain the required network statement.

### Corrective Action

The Guest DHCP pool was configured with:

```text
  ip dhcp pool VLAN70-GUEST
  network 192.168.70.0 255.255.255.0
  default-router 192.168.70.1
  dns-server 8.8.8.8
```

### Result

The Guest laptop successfully obtained an IP address.

**Status: RESOLVED**

---

## 3. Guest ACL and DHCP Interaction

### Symptom

After implementing the Guest ACL, DHCP operation was affected.

### Investigation

The ACL was reviewed using:

```text
  show access-lists GUEST-IN
```

The ACL was applied inbound on VLAN 70:

```text
  interface Vlan70
  ip access-group GUEST-IN in
```

### Root Cause

DHCP traffic requires communication between the client and DHCP service before the client has a usable IP address.

An incorrectly restrictive ACL can therefore interfere with DHCP.

### Corrective Action

The Guest security policy was adjusted so that DHCP operation could function while maintaining isolation from protected internal networks.

### Result

The Guest laptop successfully received DHCP configuration while internal network restrictions remained operational.

**Status: RESOLVED**

---

## 4. Wireless Adapter Issue

### Symptom

The Guest laptop initially could not connect to the wireless network.

Packet Tracer indicated that a wireless adapter was required.

### Investigation

The laptop's available hardware was inspected.

### Root Cause

The laptop required a compatible wireless network module.

### Corrective Action

A WPC300N wireless adapter was installed in the Guest laptop.

### Result

The laptop successfully connected to the Guest Access Point.

**Status: RESOLVED**

---

## 5. Guest Access Point VLAN Assignment

### Verification

SW4-ACCESS Fa0/3 was checked using:

```text
  show interfaces fa0/3 status
  show interfaces fa0/3 switchport
```

The port was verified as:

```text
  Status: connected
  Access Mode VLAN: 70 (GUEST)
```

### Result

Guest wireless traffic was correctly placed into VLAN 70.

**Status: VERIFIED**

---

## 6. Trunk Troubleshooting

### Verification

The trunk configuration was checked using:

```text
  show interfaces trunk
```

The trunk was verified as operational.

Required VLANs were present:

```text
  10,20,30,40,50,60,70,99
```

VLAN 70 was confirmed to be:

```text
  Allowed
  Active
  Forwarding
```

**Status: VERIFIED**

---

## 7. Inter-VLAN Routing Troubleshooting

### Verification

SW1-CORE routing was checked using:

```text
  show ip route
```

The following networks were confirmed as directly connected:

```text
  192.168.10.0/24
  192.168.20.0/24
  192.168.30.0/24
  192.168.40.0/24
  192.168.50.0/24
  192.168.60.0/24
  192.168.70.0/24
  192.168.99.0/24
```

The transit network toward R1-EDGE was also present.

### Result

Inter-VLAN routing was operational.

**Status: VERIFIED**

---

## 8. WAN Connectivity Troubleshooting

### Symptom

Initial testing of the simulated external network produced unsuccessful ping results.

Example:

```text
  ping 198.51.100.1
```

and:

```text
  ping 198.51.100.10
```

initially returned:

```text
  Success rate is 0 percent
```

### Investigation

The following components were checked:

* R1-EDGE interfaces
* WAN addressing
* Routing
* ISP-R1
* External server
* NAT configuration

### Corrective Action

The WAN and routing configuration was corrected and connectivity was retested.

### Result

Connectivity to the simulated external network was successfully established.

**Status: RESOLVED**

---

## 9. NAT Troubleshooting

### Verification

NAT operation was checked using:

```text
  show ip nat translations
  show ip nat statistics
```

Connectivity to the simulated external server was tested using:

```text
  ping 198.51.100.10
```

### Result

NAT/PAT successfully provided external connectivity.

**Status: VERIFIED**

---

## 10. SSH Security Verification

SSH configuration was verified using:

```text
  show ip ssh
```

Management access restrictions were verified using:

```text
  show access-lists 10
```

The access switches were hardened and SSH restrictions were successfully verified.

**Status: VERIFIED**

---

## 11. General Troubleshooting Method

The following troubleshooting methodology was used:

```text
 1. Identify the symptom
        ↓
 2. Check physical/link status
        ↓
 3. Check VLAN configuration
        ↓
 4. Check IP addressing
        ↓
 5. Check routing
        ↓
 6. Check DHCP
        ↓
 7. Check ACL/security policies
        ↓
 8. Apply corrective configuration
        ↓
 9. Retest connectivity
        ↓
 10. Document the result
```

This approach helped isolate configuration problems systematically.

---

## 12. Key Lessons Learned

### VLANs Must Be Consistent End-to-End

A VLAN must exist and be allowed across every required switch link between the endpoint and its Layer 3 gateway.

### DHCP Depends on Multiple Components

A working DHCP client requires:

* Correct VLAN
* Correct access port
* Correct trunk
* Operational SVI
* Correct DHCP pool
* Appropriate ACL behavior

### ACLs Can Affect More Than Intended Traffic

Security policies must be tested carefully because an ACL designed to restrict user traffic can unintentionally interfere with required services.

### Wireless Clients Require Correct Hardware

In Packet Tracer, wireless endpoints may require an appropriate wireless adapter before they can associate with an Access Point.

### Troubleshooting Should Be Layered

Checking the physical connection, VLAN, IP addressing, routing, and security controls in sequence makes troubleshooting more efficient.

### Verification Is Essential

Configuration commands alone do not prove that a network works.

Connectivity tests and operational verification are required after implementation.

---

## 13. Verification Commands Used

The following commands were used throughout the project:

```text
  show vlan brief
  show interfaces trunk
  show ip interface brief
  show ip route
  show ip dhcp pool
  show ip dhcp binding
  show ip dhcp conflict
  show access-lists
  show ip ssh
  show ip nat translations
  show ip nat statistics
```

Connectivity was tested using:

```text
  ping
```

---

## 14. Final Troubleshooting Result

All major connectivity and security issues encountered during the implementation were resolved.

The final network successfully demonstrated:

* VLAN segmentation
* Inter-VLAN routing
* DHCP
* Guest wireless connectivity
* Guest isolation
* ACL enforcement
* SSH security
* WAN connectivity
* NAT/PAT
* Simulated Internet access

**Troubleshooting Status: Completed**

**Overall Lab Status: PASS**
