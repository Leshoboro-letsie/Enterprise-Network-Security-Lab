# Network Security Controls

## 1. Purpose

This document describes the security controls implemented in the Enterprise Network & Security Lab.

The security design uses network segmentation, access control lists, secure management, Guest isolation, device hardening, and NAT/PAT to reduce unauthorized access and improve network security.

---

## 2. Security Architecture

The network is divided into separate security zones:

```text id="t2n9p4"
                    ENTERPRISE NETWORK
                           |
        +------------------+------------------+
        |                  |                  |
   Internal VLANs      Management        Guest VLAN
        |                  |                  |
   IT / Finance / HR    VLAN 99           VLAN 70
   Users / Servers        |                  |
        |                  |                  |
        +------------------+                  |
                           |                  |
                        ACLs <----------------+
                           |
                         R1-EDGE
                           |
                          NAT
                           |
                          WAN
```

The objective is to prevent unnecessary communication between security zones while allowing required business and external connectivity.

---

## 3. VLAN Segmentation

VLAN segmentation is the primary network isolation mechanism.

The following VLANs are separated:

| VLAN | Name         | Security Purpose                  |
| ---- | ------------ | --------------------------------- |
| 10   | MANAGEMENT   | Management-related systems        |
| 20   | IT           | IT department                     |
| 30   | FINANCE      | Finance systems                   |
| 40   | HR           | HR systems                        |
| 50   | USERS        | General users                     |
| 60   | SERVERS      | Server infrastructure             |
| 70   | GUEST        | Untrusted Guest devices           |
| 99   | NETWORK-MGMT | Network infrastructure management |

This segmentation limits Layer 2 broadcast domains and provides logical security boundaries.

---

## 4. Guest Network Isolation

VLAN 70 is treated as an untrusted network.

Guest clients are prevented from directly accessing internal organizational networks.

The Guest ACL blocks traffic toward:

```text id="v3s0t9"
192.168.10.0/24
192.168.20.0/24
192.168.30.0/24
192.168.40.0/24
192.168.50.0/24
192.168.60.0/24
192.168.99.0/24
```

The Guest network can still reach permitted external destinations.

---

## 5. Guest ACL

The Guest ACL is named:

```text id="zqdfc8"
  GUEST-IN
```

The ACL is applied inbound to VLAN 70:

```text id="5uk8ct"
  interface Vlan70
  ip access-group GUEST-IN in
```

The ACL implements the following security model:

```text id="gk76q1"
  Guest → Internal Networks     DENY
  Guest → External Network      PERMIT
  Guest → Required Services     PERMIT
```

The ACL was verified using:

```text id="bqizf0"
  show access-lists GUEST-IN
```

---

## 6. DHCP Protection

The Guest ACL was configured to allow DHCP operation.

This is important because DHCP clients initially do not have an IP address and therefore require DHCP communication to obtain network configuration.

After correcting the ACL, the Guest laptop successfully received an address from the VLAN 70 DHCP pool.

---

## 7. Departmental ACL Controls

ACLs were also configured and tested for departmental security policies.

The following areas were tested:

* IT
* Finance
* HR
* Management

The objective is to restrict unauthorized access while allowing required business communication.

ACL verification was performed using:

```text id="j38lfc"
  show access-lists
```

---

## 8. SSH Secure Management

SSH was implemented for secure remote management of network devices.

SSH provides encrypted administrative communication.

The access switches were configured to support SSH management.

Management access is restricted using an access control list.

Example management ACL:

```text id="uws7df"
  access-list 10
```

The ACL limits which source networks can access the device management plane.

SSH verification was performed using:

```text id="p7m44p"
show ip ssh
show access-lists 10
```

---

## 9. Management Network

Network management is separated from normal user traffic.

The management VLANs are:

```text id="d0k1mc"
  VLAN 10 - MANAGEMENT
  VLAN 99 - NETWORK-MGMT
```

This separation reduces exposure of network administration services to ordinary users and Guest devices.

---

## 10. Switch Hardening

The access switches were hardened as part of the security configuration.

Security measures include:

* Secure administrative access
* SSH management
* Management ACL restrictions
* VLAN segmentation
* Controlled access ports
* Trunk configuration
* Dedicated management networks

SW2-ACCESS, SW3-ACCESS, and SW4-ACCESS were hardened and verified.

---

## 11. Access Port Security

Access ports are assigned to specific VLANs based on their intended function.

Example Guest AP port:

```text id="b07m21"
  interface FastEthernet0/3
  switchport mode access
  switchport access vlan 70
```

This ensures that traffic from the Guest Access Point enters the network as VLAN 70 traffic.

---

## 12. Trunk Security

The core-to-access trunk carries only the VLANs required by the enterprise design.

Verified VLANs:

```text id="4q2mvn"
  10,20,30,40,50,60,70,99
```

Trunk operation was verified using:

```text id="4d9q90"
  show interfaces trunk
```

The Guest VLAN is transported across the required trunk links so that wireless Guest clients can reach the Layer 3 gateway.

---

## 13. NAT/PAT Security

NAT/PAT is implemented on R1-EDGE.

Private RFC1918 addresses are translated before reaching the simulated external network.

This provides address translation between the internal enterprise network and the WAN.

NAT verification was performed using:

```text id="f8c1f6"
  show ip nat translations
  show ip nat statistics
```

---

## 14. WAN Security Boundary

R1-EDGE acts as the boundary between the internal enterprise network and the simulated ISP.

Traffic leaving the internal network passes through the edge router.

The edge router provides:

* WAN connectivity
* NAT/PAT
* Routing
* Network boundary control

---

## 15. Server Network Protection

Servers are placed in a dedicated VLAN:

```text id="0ry2tw"
  VLAN 60 - SERVERS
  192.168.60.0/24
```

Separating servers from normal users allows security policies to control access to server resources independently.

---

## 16. Security Testing

Security controls were tested using:

```text id="76u8bw"
  show access-lists
  show ip ssh
  show interfaces trunk
  show ip interface brief
  show ip route
  show ip nat translations
```

End-to-end connectivity tests were also performed.

---

## 17. Guest Security Test

The Guest laptop was tested to verify:

```text id="w8l8ay"
  Guest → Guest Gateway       PASS
  Guest → External Network    PASS
  Guest → Internal Networks   BLOCKED
```

This confirms that the Guest network is isolated while maintaining permitted external connectivity.

---

## 18. Security Troubleshooting

During implementation, the Guest network initially experienced DHCP failures.

The issue was investigated by checking:

```text id="w3ux6y"
  DHCP pool configuration
  VLAN configuration
  Trunk configuration
  SVI status
  ACL configuration
```

The DHCP pool and Guest ACL were corrected.

After correction, the Guest laptop successfully received an IP address.

---

## 19. Security Principles Applied

The design applies the following security principles:

### Least Privilege

Users and Guest devices receive only the network access required for their intended role.

### Network Segmentation

Different departments and security zones are separated using VLANs.

### Defense in Depth

Multiple controls are used together:

* VLANs
* ACLs
* SSH
* Management restrictions
* NAT/PAT
* Network hardening

### Secure Management

Administrative access uses SSH rather than insecure Telnet.

### Guest Isolation

Untrusted Guest devices are separated from internal enterprise resources.

---

## 20. Security Verification Summary

| Security Control    | Result |
| ------------------- | ------ |
| VLAN Segmentation   | PASS   |
| Guest Isolation     | PASS   |
| Guest ACL           | PASS   |
| Departmental ACLs   | PASS   |
| SSH Management      | PASS   |
| Management ACL      | PASS   |
| Switch Hardening    | PASS   |
| Trunk Configuration | PASS   |
| NAT/PAT             | PASS   |
| WAN Boundary        | PASS   |
| Guest DHCP          | PASS   |
| Guest Wireless      | PASS   |

---

## 21. Final Security Assessment

The lab successfully demonstrates a layered enterprise network security architecture.

Internal departments, servers, management systems, and Guest users are separated into logical security zones.

ACLs provide traffic control between these zones, while SSH protects administrative access.

The Guest network is isolated from internal resources while maintaining permitted external connectivity.

NAT/PAT provides the translation boundary between private internal addressing and the simulated external network.

**Security Implementation Status: Completed and Verified**
