# Network Topology and Device Roles

## 1. Purpose

This document describes the physical and logical topology of the Enterprise Network & Security Lab and defines the role of each network device.

The topology follows a simplified enterprise architecture consisting of:

* Core Layer
* Access Layer
* Edge/WAN Layer
* Wireless Guest Network
* Simulated ISP
* External Server

---

## 2. Logical Topology

```text
                           ISP-SERVER
                         198.51.100.10
                                |
                                |
                             ISP-R1
                                |
                                |
                           R1-EDGE
                                |
                                |
                           SW1-CORE
                         Layer 3 Core
                                |
              +-----------------+-----------------+
              |                 |                 |
              |                 |                 |
          SW2-ACCESS        SW3-ACCESS        SW4-ACCESS
              |                 |                 |
           Endpoints         Endpoints           AP
                                                  |
                                                  |
                                            LAPTOP-GUEST
```

---

## 3. Core Layer

### SW1-CORE

**Role:** Enterprise Core / Layer 3 Switch

SW1-CORE is the central Layer 3 switching device.

Primary responsibilities:

* VLAN management
* Inter-VLAN routing
* SVI gateways
* DHCP services
* ACL enforcement
* Core-to-edge routing
* Connection to access switches

Configured VLAN gateways include:

```text
  VLAN 10 → 192.168.10.1
  VLAN 20 → 192.168.20.1
  VLAN 30 → 192.168.30.1
  VLAN 40 → 192.168.40.1
  VLAN 50 → 192.168.50.1
  VLAN 60 → 192.168.60.1
  VLAN 70 → 192.168.70.1
  VLAN 99 → 192.168.99.1
```

SW1-CORE also provides the routed connection toward R1-EDGE.

---

## 4. Access Layer

### SW2-ACCESS

**Role:** Access Layer Switch

SW2-ACCESS provides connectivity for end-user devices and departmental VLANs.

Primary functions:

* End-device connectivity
* VLAN assignment
* Trunk connectivity
* Secure management
* Network segmentation

---

### SW3-ACCESS

**Role:** Access Layer Switch

SW3-ACCESS provides additional endpoint connectivity.

Primary functions:

* End-device connectivity
* VLAN assignment
* Trunk connectivity
* Secure management
* Network segmentation

The switch was hardened and verified as part of the security implementation.

---

### SW4-ACCESS

**Role:** Access Layer Switch / Wireless Access

SW4-ACCESS provides endpoint connectivity and connects the Guest Access Point.

The Guest AP connection uses:

```text
  SW4-ACCESS Fa0/3
        |
  VLAN 70 - GUEST
```

SW4-ACCESS was hardened and verified.

---

## 5. Edge Layer

### R1-EDGE

**Role:** Enterprise Edge Router

R1-EDGE provides the boundary between the internal enterprise network and the simulated external network.

Primary responsibilities:

* WAN connectivity
* Routing
* NAT/PAT
* External network access
* Enterprise network boundary

The internal transit connection uses:

```text
  10.255.255.0/30
```

The WAN connection uses:

```text
  203.0.113.0/30
```

---

## 6. ISP Layer

### ISP-R1

**Role:** Simulated ISP Router

ISP-R1 represents the external service provider.

It provides connectivity between R1-EDGE and the simulated external network.

The external network uses:

```text
  198.51.100.0/24
```

ISP-R1 provides the gateway:

```text
  198.51.100.1
```

---

## 7. External Server

### ISP-SERVER

**Role:** Simulated External Internet Server

The server represents an Internet-accessible resource.

Addressing:

```text
  IP Address: 198.51.100.10
  Subnet Mask: 255.255.255.0
  Gateway: 198.51.100.1
```

The server is used to test:

* WAN connectivity
* Routing
* NAT/PAT
* End-to-end connectivity

---

## 8. Wireless Network

### AP-GUEST

**Role:** Guest Wireless Access Point

The Access Point provides wireless access to Guest clients.

The AP connects to:

```text
  SW4-ACCESS Fa0/3
```

The switch port is configured for:

```text
  VLAN 70 - GUEST
```

---

### LAPTOP-GUEST

**Role:** Guest Wireless Client

The Guest laptop uses a WPC300N wireless adapter.

The laptop connects wirelessly to the Guest Access Point.

The client receives its IPv4 configuration through DHCP.

Expected network:

```text
  Network: 192.168.70.0/24
  Gateway: 192.168.70.1
```

---

## 9. Core-to-Access Connectivity

The access switches connect to SW1-CORE using 802.1Q trunk links.

The required VLANs carried across the trunk are:

```text
  10
  20
  30
  40
  50
  60
  70
  99
```

Trunk operation was verified using:

```text
  show interfaces trunk
```

---

## 10. Core-to-Edge Connectivity

SW1-CORE connects to R1-EDGE using a Layer 3 transit network.

Network:

```text
  10.255.255.0/30
```

The routed connection provides the path from internal VLANs toward the enterprise edge.

---

## 11. Edge-to-ISP Connectivity

R1-EDGE connects to ISP-R1 through the simulated WAN.

Network:

```text
203.0.113.0/30
```

This connection provides access to the simulated external network.

---

## 12. External Connectivity Path

The complete external traffic path is:

```text
  Internal Client
      |
  Access Switch
      |
   SW1-CORE
      |
    R1-EDGE
      |
    NAT/PAT
      |
    ISP-R1
      |
   ISP-SERVER
```

This path was successfully tested.

---

## 13. Guest Traffic Path

Guest wireless traffic follows:

```text
 LAPTOP-GUEST
      |
   Wireless
      |
 AP-GUEST
      |
 SW4-ACCESS
      |
   VLAN 70
      |
   SW1-CORE
      |
      +----> Internal Networks  BLOCKED
      |
    R1-EDGE
      |
    ISP-R1
      |
   ISP-SERVER
```

The Guest network is isolated from protected internal networks by the Guest ACL.

---

## 14. Device Summary

| Device       | Role            | Primary Function                   |
| ------------ | --------------- | ---------------------------------- |
| SW1-CORE     | Core Layer      | VLANs, routing, DHCP, ACLs         |
| SW2-ACCESS   | Access Layer    | Endpoint connectivity              |
| SW3-ACCESS   | Access Layer    | Endpoint connectivity              |
| SW4-ACCESS   | Access Layer    | Endpoint and Guest AP connectivity |
| R1-EDGE      | Edge Router     | WAN, routing, NAT/PAT              |
| ISP-R1       | Simulated ISP   | External routing                   |
| ISP-SERVER   | External Server | Internet connectivity testing      |
| AP-GUEST     | Wireless AP     | Guest wireless access              |
| LAPTOP-GUEST | Wireless Client | Guest network testing              |

---

## 15. Architecture Characteristics

The topology demonstrates:

* Hierarchical network design
* Layer 3 core switching
* Layer 2 access switching
* VLAN segmentation
* 802.1Q trunking
* Dedicated management networks
* Dedicated server network
* Dedicated Guest network
* Secure network management
* Edge routing
* NAT/PAT
* Simulated Internet connectivity

---

## 16. Topology Verification

The topology was verified through:

```text
  show vlan brief
  show interfaces trunk
  show ip interface brief
  show ip route
  show ip dhcp pool
  show ip dhcp binding
  show access-lists
  show ip ssh
  show ip nat translations
  show ip nat statistics
```

End-to-end connectivity tests were also performed between internal clients, the Guest network, R1-EDGE, ISP-R1, and the simulated external server.

---

## 17. Final Topology Status

The complete enterprise topology was successfully implemented and tested.

All major components were connected and operational, including:

* Core switch
* Access switches
* Edge router
* ISP router
* External server
* Guest Access Point
* Guest wireless laptop

**Topology Status: Completed and Verified**
